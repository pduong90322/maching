#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=asia1-etc.ethermine.org:4444
WALLET=0x407941ac75bed1d45c05a0db43fce7120354b16c.worker
ARG=15

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --algo ETCHASH --pool $POOL --user $WALLET $@ --keepfree $arg
