#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=etc.ethermine.org:4444
WALLET=0x4a1a9b8e06987cbc27a804543793b93492f6adac.WorkerName

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./etc --algo ETCHASH --pool $POOL --user $WALLET $@
