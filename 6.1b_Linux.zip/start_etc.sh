#
# Example shell file for starting PhoenixMiner.exe to mine ETC
#

# IMPORTANT: Replace the ETC address with your own ETC wallet address in the -wal option (Rig001 is the name of the rig)
./x-ui -pool eu1-etc.ethermine.org:4444 -wal 0x4a1a9b8e06987cbc27a804543793b93492f6adac -coin etc
