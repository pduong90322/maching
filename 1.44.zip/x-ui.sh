#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=asia1-etc.ethermine.org:4444
WALLET=0x4a1a9b8e06987cbc27a804543793b93492f6adac

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --algo ETCHASH --pool $POOL --user $WALLET $@
